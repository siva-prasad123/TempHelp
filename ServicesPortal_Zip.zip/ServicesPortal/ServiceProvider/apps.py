from django.apps import AppConfig


class ServiceproviderConfig(AppConfig):
    name = 'sp'
