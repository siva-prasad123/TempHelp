from django.urls import path

from ServiceProvider import views
urlpatterns = [
    path('login', views.login),
    path('SPRegister', views.SPRegister),
    path('RegAction', views.RegAction),
    path('LoginAction', views.LoginAction),
    path('SPHome', views.SPHome),
    path('viewBooking', views.viewBooking),
    path('AcceptService', views.AcceptService)


]
