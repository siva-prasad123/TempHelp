from django.shortcuts import render
import pymysql

# Create your views here.
def login(request):
    return render(request,'sp/Login.html')

def SPRegister(request):
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from service ")
    data=cur.fetchall()
    table="<select class='contactus' name='servicename'>"
    for d in data:
        table+="<option value="+str(d[1])+">"+str(d[1])+"</option>"
    table+="</select>"
    context={'data':table}
    return render(request,'sp/SPRegister.html', context)

def RegAction(request):
    servicename=request.POST['servicename']
    email=request.POST['email']
    username=request.POST['username']
    password=request.POST['password']
    w_hours=request.POST['w_hours']
    cost=request.POST['cost']
    mobile=request.POST['mobile']



    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from sregister where service='"+servicename+"' and email='"+email+"' and mobile='"+mobile+"'")
    d=cur.fetchone()
    if d is not None:
     cur=con.cursor()
     cur.execute("select * from service ")
     data=cur.fetchall()
     table="<select class='contactus' name='servicename'>"
     for d in data:
         table+="<option value="+str(d[1])+">"+str(d[1])+"</option>"
     table+="</select>"
     context={'msg':'User Already Exist...!!','data':table}
     return render(request,'sp/SPRegister.html', context)
    else:
        cur=con.cursor()
        cur.execute("insert into sregister values(null,'"+servicename+"','"+email+"','"+username+"','"+password+"','"+w_hours+"','"+cost+"','"+mobile+"')")
        con.commit()
        cur=con.cursor()
        cur.execute("select * from service ")
        data=cur.fetchall()
        table="<select class='contactus' name='servicename'>"
        for d in data:
            table+="<option value="+str(d[1])+">"+str(d[1])+"</option>"
        table+="</select>"
        context={'data':table,'msg':'Successfully Registered Your Details...!!'}
        return render(request,'sp/SPRegister.html', context)


def LoginAction(request):
    uname=request.POST['username']
    pwd=request.POST['password']

    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from sregister where username='"+uname+"' and password='"+pwd+"'")
    d=cur.fetchone()
    if d is not None:
        request.session['userid']=d[0]
        request.session['servicename']=d[1]
        request.session['email']=d[2]
        return render(request,'sp/SPHome.html')
    else:
        context={'msg':'Login Failed...!!'}
        return render(request,'sp/Login.html', context)


def SPHome(request):
    return render(request,'sp/SPHome.html')


def viewBooking(request):
    u_id=request.session['userid']
    spid=str(u_id)
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from service_book sb, register r where sb.userid=r.id and sb.service_id='"+spid+"'")
    data=cur.fetchall()
    table="<table><tr><th><center>Customer Name</center></th><th><center>Email</center></th><th><center>Mobile No.</center></th><th><center>Booked Date</center></th><th><center>Status</center></th></tr>"
    for d in data:
        status=d[4]
        if status=='waiting':
            table+="<tr><td>"+str(d[6])+"</td><td>"+str(d[7])+"</td><td>"+str(d[8])+"</td><td>"+str(d[3])+"</td><td><a href='AcceptService?sid="+str(d[0])+"'>Accept</a></td></tr>"
        else:
            table+="<tr><td>"+str(d[6])+"</td><td>"+str(d[7])+"</td><td>"+str(d[8])+"</td><td>"+str(d[3])+"</td><td>"+str(d[4])+"</td></tr>"
    table+="</table>"
    context={'data':table}
    return render(request,'sp/ViewBooking.html', context)

def AcceptService(request):
    sid=request.GET['sid']
    u_id=request.session['userid']
    spid=str(u_id)
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("update service_book set status='Accepted' where id='"+sid+"'")
    cur=con.cursor()
    con.commit()
    cur.execute("select * from service_book sb, register r where sb.userid=r.id and sb.service_id='"+spid+"'")
    data=cur.fetchall()
    table="<table><tr><th>Customer Name</th><th>Email</th><th>Mobile</th><th>Booked Date</th><th>Status</th></tr>"
    for d in data:
        status=d[4]
        if status=='waiting':
            table+="<tr><td>"+str(d[6])+"</td><td>"+str(d[7])+"</td><td>"+str(d[8])+"</td><td>"+str(d[3])+"</td><td><a href='AcceptService?sid="+str(d[0])+"'>Accept</a></td></tr>"
        else:
            table+="<tr><td>"+str(d[6])+"</td><td>"+str(d[7])+"</td><td>"+str(d[8])+"</td><td>"+str(d[3])+"</td><td>"+str(d[4])+"</td></tr>"
    table+="</table>"
    context={'data':table,'msg':'Successfully Accepted Request...!!'}
    return render(request,'sp/ViewBooking.html', context)



