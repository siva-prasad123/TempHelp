from django.shortcuts import render
import pymysql

# Create your views here.
def index(request):
    return render(request,'index.html')
def login(request):
    return render(request,'Customer/Login.html')

def Register(request):
    return render(request,'Customer/Register.html')

def RegAction(request):
    name=request.POST['name']
    email=request.POST['email']
    mobile=request.POST['mobile']
    address=request.POST['address']
    username=request.POST['username']
    password=request.POST['password']


    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from register where  email='"+email+"' and mobile='"+mobile+"'")
    d=cur.fetchone()
    if d is not None:

     context={'msg':'Already Exist These Details...!!'}
     return render(request,'Customer/Register.html', context)
    else:
        cur=con.cursor()
        cur.execute("insert into register values(null,'"+name+"','"+email+"','"+mobile+"','"+address+"','"+username+"','"+password+"')")
        con.commit()
        context={'msg':'Successfully Registered Your Details...!!'}
        return render(request,'Customer/Register.html', context)

def LogAction(request):
    uname=request.POST['username']
    pwd=request.POST['password']

    con=pymysql.connect(host='localhost', user='root', password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from register where username='"+uname+"' and password='"+pwd+"'")
    d=cur.fetchone()
    if d is not None:
        request.session['userid']=d[0]
        request.session['name']=d[1]
        request.session['email']=d[2]
        return render(request, 'Customer/CustomerHome.html')
    else:
        context={'msg':'Login Failed...!!'}
        return render(request, 'Customer/Login.html',context)

def CustomerHome(request):
    return render(request,'Customer/CustomerHome.html')

def ViewService(request):
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()

    cur.execute("select * from sregister")
    data=cur.fetchall()
    table="<table><tr><th>Service Name</th><th>Email</th><th>Mobile</th><th>Working Hours</th><th>Cost</th><th>Book</th></tr>"
    for d in data:
        table+="<tr><td>"+str(d[1])+"</td><td>"+str(d[2])+"</td><td>"+str(d[7])+"</td><td>"+str(d[5])+"</td><td>Rs."+str(d[6])+"</td><td><a href='BookService?sid="+str(d[0])+"'>Book Now</a></td></tr>"
    table+="</table>"
    context={'data':table}
    return render(request,'Customer/ViewServices.html', context)
def BookService(request):
    service_id=request.GET['sid']
    uid=request.session['userid']
    user_id=str(uid)

    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("insert into service_book values(null,'"+user_id+"','"+service_id+"',now(),'waiting')")
    con.commit()
    cur.execute("select * from sregister")
    data=cur.fetchall()
    table="<table><tr><th><center>Service Name</center></th><th><center>Email</center></th><th><center>Mobile No.</center></th><th><center>Working Hours</center></th><th><center>Cost</center></th><th><center>Book</center></th></tr>"
    for d in data:
        table+="<tr><td>"+str(d[1])+"</td><td>"+str(d[2])+"</td><td>"+str(d[7])+"</td><td>"+str(d[5])+"</td><td>Rs."+str(d[6])+"</td><td><a href='BookService?sid="+str(d[0])+"'>Book Now</a></td></tr>"
    table+="</table>"
    context={'data':table,'msg':'Booking Successful ...!!'}
    return render(request,'Customer/ViewServices.html', context)


def ViewProducts(request):
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()

    cur.execute("select * from product p, skregister sk where p.shop_id=sk.id")
    data=cur.fetchall()
    table="<table><tr><th><center>Service Name</center></th><th><center>Address</center></th><th><center>Mobile No.</center></th><th><center>Product Name</center></th><th><center>Price</center></th><th><center>Available</center></th><th><center>Usage</center></th><th><center>Book Now</center></th></tr>"
    for d in data:
        table+="<tr><td>"+str(d[7])+"</td><td>"+str(d[9])+"</td><td>"+str(d[10])+"</td><td>"+str(d[2])+"</td><td>Rs."+str(d[3])+"</td><td>"+str(d[4])+"</td><td>"+str(d[5])+"</td><td><a href='BookProduct?pid="+str(d[0])+"&shop_id="+str(d[1])+"'>Book Now</a></td></tr>"
    table+="</table>"
    context={'data':table}
    return render(request,'Customer/ViewProducts.html', context)

def BookProduct(request):
    pid=request.GET['pid']
    shop_id=request.GET['shop_id']
    uid=request.session['userid']
    user_id=str(uid)
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("insert into product_book values(null,'"+user_id+"','"+pid+"','"+shop_id+"',now(),'waiting')")
    con.commit()
    cur.execute("select * from product p, skregister sk where p.shop_id=sk.id")
    data=cur.fetchall()
    table="<table><tr><th><center>Service Name</center></th><th><center>Address</center></th><th><center>Mobile</center></th><th><center>Product Name</center></th><th><center>Price</center></th><th><center>Available</center></th><th><center>Usage</center></th><th><center>Book Now</center></th></tr>"
    for d in data:
        table+="<tr><td>"+str(d[7])+"</td><td>"+str(d[9])+"</td><td>"+str(d[10])+"</td><td>"+str(d[2])+"</td><td>Rs."+str(d[3])+"</td><td>"+str(d[4])+"</td><td>"+str(d[5])+"</td><td><a href='BookProduct?pid="+str(d[0])+"&shop_id="+str(d[1])+"'>Book Now</a></td></tr>"
    table+="</table>"
    context={'data':table,'msg':'Product Booked Successfully..!!'}
    return render(request,'Customer/ViewProducts.html', context)


def viewbookings(request):
    uid=request.session['userid']
    user_id=str(uid)
    con=pymysql.connect(host='localhost', user='root',password='root', database='service_portal', charset='utf8')
    cur=con.cursor()
    cur.execute("select * from product_book pb, product p where p.id=pb.product_id and pb.user_id='"+user_id+"'")
    data=cur.fetchall()
    table="<table><tr><th><center>Product Name</center></th><th><center>Price</center></th><th><center>Available</center></th><th><center>Usage</center></th><th><center>Booked Date</center></th><th><center>Status</center></th><tr>"
    for d in data:
        table+="<tr><td>"+str(d[8])+"</td><td>"+str(d[9])+"</td><td>"+str(d[10])+"</td><td>"+str(d[11])+"</td><td>"+str(d[4])+"</td><td>"+str(d[5])+"</td></tr>"
    table+="</table>"

    cur1=con.cursor()
    cur1.execute("select * from service_book sb, sregister sr where sb.service_id=sr.id and sb.userid='"+user_id+"'")
    data=cur1.fetchall()
    srtable="<table><tr><th><center>Service Name</center></th><th><center>Email</center></th><th><center>Mobile</center></th><th><center>Working Hours</center></th><th><center>Cost</center></th><th><center>Booked Date</center></th><th><center>Booking Status</center></th></tr>"
    for d in data:
        srtable+="<tr><td>"+str(d[6])+"</td><td>"+str(d[7])+"</td><td>"+str(d[12])+"</td><td>"+str(d[10])+"</td><td>Rs."+str(d[11])+"</td><td>"+str(d[3])+"</td><td>"+str(d[4])+"</td></tr>"
    srtable+="</table>"
    context={'data':table,'servicetable':srtable}
    return render(request,'Customer/ViewAllBookings.html', context)




