from django.apps import AppConfig


class ShopkeeperConfig(AppConfig):
    name = 'sk'
